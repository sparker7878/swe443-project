package Profile.SYTech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SyTechApplicationTests {

	@Test
	void contextLoads() {
	}

}
