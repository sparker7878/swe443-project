package Profile.SYTech;


import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.QuerySnapshot;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.concurrent.ExecutionException;


@Controller
public class UserController {
    @Autowired
    FirebaseService Fservice;

    @GetMapping("/Profile")
    public String displayProfile(Model model) throws ExecutionException, InterruptedException {
        String cid = Fservice.getCurrentID();
        User user = Fservice.getUser(cid);
        model.addAttribute("user", user);
        return "index";
    }
    @PostMapping("/Profile")
    public String saveProfile(@ModelAttribute("user") User user, Model model) throws ExecutionException, InterruptedException {
        Fservice.setUser(user);
        model.addAttribute("user", user);
        return "save";
    }

}

