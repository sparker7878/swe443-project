package Profile.SYTech;

public enum Foods2 {
    Mexican,
    Italian,
    Thai,
    American,
    Seafood,
    Greek,
    Indian,
    Chinese
}
