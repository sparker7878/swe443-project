package Profile.SYTech;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import com.google.firebase.cloud.FirestoreClient;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

@Service
public class FirebaseService {
    private Firestore db = FirestoreClient.getFirestore();


    //Get the current User ID
    public String getCurrentID() throws ExecutionException, InterruptedException {
        DocumentReference docRef = db.collection("Login").document("CurrentUser");
        ApiFuture<DocumentSnapshot> docSnap = docRef.get();
        DocumentSnapshot doc = docSnap.get();
        return doc.getString("currID");
    }
    //Set the current User ID
    public void setCurrentID(String id) throws ExecutionException, InterruptedException {
        db.collection("Login").document("CurrentUser").update("currID", id);
    }

    //Get the id given login email
    public String getID(String logEmail) throws ExecutionException, InterruptedException {
        DocumentReference docRef = db.collection("Login").document(logEmail);
        ApiFuture<DocumentSnapshot> docSnap = docRef.get();
        DocumentSnapshot doc = docSnap.get();
        return doc.getString("id");
    }

    //Get the user given the firebase id
    public User getUser(String id) throws ExecutionException, InterruptedException {
        DocumentReference docRef = db.collection("User").document(id);
        ApiFuture<DocumentSnapshot> docSnap = docRef.get();
        DocumentSnapshot doc = docSnap.get();
        return doc.toObject(User.class);
    }

    //Save the user object in the database
    public void setUser(User user) throws ExecutionException, InterruptedException {
        ArrayList<Foods2> likes = user.getfoodLikes();
        ArrayList<Foods2> Dislikes = user.getfoodDislikes();
        String current = getCurrentID();
        User tempUser = getUser(current);
        tempUser.setfoodLikes(likes);
        tempUser.setfoodDislikes(Dislikes);
        db.collection("User").document(current).set(tempUser);
    }
}
