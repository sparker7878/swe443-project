package Profile.SYTech;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.concurrent.ExecutionException;


@Controller
public class LoginController {
    @Autowired
    FirebaseService serviceF;

    @GetMapping("/Login")
    public String LoginPage(Model model){
        LoginModel login = new LoginModel("user", "pass");
        model.addAttribute("login", login);
        return "loginView2";
    }
    @PostMapping("/Login")
    public String LoginAction(@ModelAttribute("login") LoginModel login, Model model) throws ExecutionException, InterruptedException {
        String remail = login.getUsername();
        String rid = serviceF.getID(remail);
        User currUser = serviceF.getUser(rid);
        serviceF.setCurrentID(rid);
        model.addAttribute("login", login);
        model.addAttribute("user", currUser);
        return "save";
    }

}
