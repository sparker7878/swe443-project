package Profile.SYTech;

import org.springframework.stereotype.Component;
import java.util.ArrayList;


@Component
public class User {
    private String name;
    private ArrayList<Foods2> foodDislikes;
    private ArrayList<Foods2> foodLikes;
    private String email;

    public User(){
        super();
    }
    public User(String name, String email){
        this.name = name;
        this.email = email;
    }
    public String getname(){
        return name;
    }
    public ArrayList<Foods2> getfoodDislikes(){
        return foodDislikes;
    }
    public void setfoodDislikes(ArrayList<Foods2> foodDislikes){
        this.foodDislikes = foodDislikes;
    }
    public ArrayList<Foods2> getfoodLikes(){
        return foodLikes;
    }
    public void setfoodLikes(ArrayList<Foods2> foodLikes){
        this.foodLikes = foodLikes;
    }
    public String getemail(){
        return email;
    }
    public void setemail(String email){
        this.email = email;
    }
}